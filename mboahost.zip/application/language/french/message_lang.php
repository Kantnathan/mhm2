<?php
   $lang [ 'welcome_message' ] =  'bienvenue dans  CodexWorld' ;
;?>