<?php
    $lang['login_heading']         = 'Login';

   $lang [ 'welcome_message' ] =  'Welcome to CodexWorld' ;
;?>